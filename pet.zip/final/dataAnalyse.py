from numpy import product
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


# %matplotlib inline
# %config InlineBackend.figure_format = 'svg'  #jupyter中解决坐标轴文字不清晰
# plt.rcParams['font.sans-serif']=['SimHei']  #解决中文乱码

# %matplotlib inline
# %config InlineBackend.figure_format = 'svg'  #jupyter中解决坐标轴文字不清晰

datafile = "./JD2019.xlsx"

df = pd.read_excel(datafile)
#print(df.head())

df1 = df.set_index("日期")

#print(df1.head())

#筛选行
df2 = pd.concat([df1["2019-02"],df1["2020-02"]])
#print(df2)

#进一步筛选行
df2 = df2[df2['商品名称']=='零基础学Python（全彩版）']
print(df2.head())

#切片所需数据[行:行,列:列]
df2 = df2.iloc[:,3:]
#print(df2)

#按需转换行与列
df3 = df2.T
print(df3)

#创建x轴数据
x = np.array(list(range(7)))
#print(x)

#y轴数据
y1=df3['2019-02-01']
y2=df3['2020-02-01']

#计算同比增长率
df3['rate'] = (y2 - y1)/y1*100

#print(df3['rate'].head())
#创建画布x坐标系
plt.xticks(x,df3.index.tolist())
#y轴标签
plt.ylabel = "销量"

width=0.25
plt.bar(x,y1,width=width)
plt.bar(x+0.25,y2,width=width)


#设定bar上标识文本
y = df3["rate"]
for a,b in zip(x,y):
    plt.text(a,b,f'{b:1f}%',ha='center',va='bottom',fontsize = 10)


plt.show()



#df2 = pd.concat([df1["B01"],df1["B04"]])

#print(df2.head())
