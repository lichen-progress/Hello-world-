

import pandas as pd
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif']=['SimHei']  #解决中乱码


df1=pd.read_excel('./广告费.xlsx')
df2=pd.read_excel('./销售表.xlsx')


#print(df1)
df1=df1.set_index('投放日期')
df2=df2[["日期","销售收入"]]
df2=df2.set_index("日期")
# print(df1['2019-01-01'])

df_x=df1.resample('M').sum().to_period('M')
df_y=df2.resample('M').sum().to_period('M')

y1=df_x["支出"]
y2=df_y["销售收入"]

fig = plt.figure(figsize=(10,14))

ax = fig.subplots(2,1)

ax1 = ax[0]


x=list(range(12))



ax2 = ax1.twinx()
#广告支出折线图和收入折线图
plt.xticks(x,[str(i)+'月' for i in range(1,13)])

ax1.plot(x,y1,'b-o',label='广告费')
plt.xticks(x,[str(i)+'月' for i in range(1,13)])
ax2.plot(x,y2,color='orange',linestyle='-',marker ='o' ,label = '收入')






plt.show()