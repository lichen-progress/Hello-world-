import pandas as pd
import matplotlib.pyplot as plt


df = pd.read_excel('./销售表.xlsx')
df1=df[['日期','销售收入']]

df1 = df1.set_index('日期')


#聚合分类 日期格式
df_d=df1.resample("D").sum()#D M Y
#print(df_d)
df_m=df1.resample("M").sum()
#print(df_m)


#plt绘图
#画布创建
fig = plt.figure(figsize=(9,9))
#分割坐标系
ax=fig.subplots(2,1)
#绘图
df_d.plot(ax=ax[0],color='r')
df_m.plot(ax=ax[1],kind='bar',color='g')
plt.show()
