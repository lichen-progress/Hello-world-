from lxml import etree
import requests
import time

#这个文件用来爬取“https://www.talkenglish.com/lessondetails.aspx?ALID=2001”至“···=2091” 的单词，可修改
#弄完记得删注释！


#爬取函数 参数为爬取网址和数据命名代码
def paQu(html_url,data_code):
    #1发起Http请求
    #2 提取response 对象内容
    #存储数据
    #html_url = "https://www.talkenglish.com/lessondetails.aspx?ALID=2001"
    #用于存储音频的目录
    audio_file = "D:/code/pet/data/English Speaking Basics/audio/"
    #用于存储文本的目录
    text_file = "D:/code/pet/data/English Speaking Basics/text/"
    
    #发起请求
    r1 = requests.get(html_url)
    #返回200 成功！
    print(r1.status_code)


    #使用utf—8编码

    r1.encoding = 'utf-8'

    #转化为etree对象！
    html = etree.HTML(r1.text)

    #print(html)
    #使用XPath来搜索抓取段落！

    title = html.xpath('//h1/text()')
    title=''.join(title).strip()
    print(title)

    content = html.xpath("//div[@class='sm2-playlist-bd']//text()")

    content='\n'.join(content).strip( )
    #a = etree.tostring(content[0],encoding = 'utf-8')
    print(content)
    t1 = open((text_file + str(f'{data_code}.txt')),'w')
    t1.write(content)
    t1.close()

    #抓取mp3网址,在div下第一个span中的a中
    mp3_url = html.xpath("//div[@class='sm2-playlist-bd']/span[1]/a/@href")

    #mp3_text = etree.tostring(mp3[0],encoding='utf-8').decode('utf-8')

    #下载MP3
    mp3 = requests.get(mp3_url[0])
    print(mp3.status_code)

    mp3_file = audio_file + str(f'{data_code}.mp3')
    f1 = open(mp3_file,'wb')
    f1.write(mp3.content)
    f1.close()

#网页列表，修改range（）范围即可爬取更广
urllist = ["https://www.talkenglish.com/lessondetails.aspx?ALID="+ str(i) for i in range(2001,2091) ]

print (urllist)

def dofenlei(urllist):
    num_list = []
    for i in urllist[0:10]:
        num_list.append(int(i[-4:]))
        paQu(i,num_list[-1])
        time.sleep(5)
    
    

dofenlei(urllist)
"""
def getText():
    

#1发起Http请求
#2 提取response 对象内容
#存储数据
html_url = "https://www.talkenglish.com/lessondetails.aspx?ALID=2001"

#发起请求
r1 = requests.get(html_url)
#返回200 成功！
print(r1.status_code)


#使用utf—8编码

r1.encoding = 'utf-8'

#转化为etree对象！
html = etree.HTML(r1.text)

#print(html)
#使用XPath来搜索抓取段落！

title = html.xpath('//h1/text()')
title=''.join(title).strip()
print(title)

content = html.xpath("//div[@class='sm2-playlist-bd']//text()")

content='\n'.join(content).strip( )
#a = etree.tostring(content[0],encoding = 'utf-8')
print(content)

#抓取mp3网址,在div下第一个span中的a中
mp3_url = html.xpath("//div[@class='sm2-playlist-bd']/span[1]/a/@href")

#mp3_text = etree.tostring(mp3[0],encoding='utf-8').decode('utf-8')

#下载MP3
time.sleep(5)
mp3 = requests.get(mp3_url[0])
print(mp3.status_code)

mp3_file = 'D:/code/pet/data/02.mp3'
f1 = open(mp3_file,'wb')
f1.write(mp3.content)
f1.close()
"""