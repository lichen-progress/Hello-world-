#使用jieba库进行中文分词
import jieba as jb

s0='中华人民民主共和国国是一个伟大的国家'
#三种分词模式
#精确模式 列出最有可能的分句
s1= jb.lcut(s0)

print(s1)

#全模式 列出所有可能的分句
s2=jb.lcut(s0,cut_all = True)

print(s2)



#使用set()来创建不重复元素集
#set() 函数创建一个无序不重复元素集，可进行关系测试，删除重复数据，还可以计算交集、差集、并集等。

s4 = set(s0)
print(s4)

dicts = {}

for w in s4:#统计各个词出现的个数
    print(w,s0.count(w))
    #添加到列表
    dicts[w] = s0.count(w)


print(dicts)

#对列表排序，以次数为标准

list_w = sorted(list(dicts.items()),key=lambda x:-x[1],reverse= True)
print(list_w)

