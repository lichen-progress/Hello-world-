from wordcloud import WordCloud
import matplotlib.pyplot as plt
import jieba
import wordcloud

src = './newstext/testword.txt'
testtext = 'wo'
print(testtext.__len__())

f = open(src,'r',encoding="utf-8")
text = f.read()
#print(text)
#采集词语
words = jieba.lcut(text)
f.close()
#print(words)
#删除多余的单词 ，如 单字，空格，换行符，标点符号等

for i in words:
    if ' ' in words:
        words.remove(' ')

    if '\n' in words:
        words.remove('\n')

print(words)

words = [i for i in words if i.__len__() > 1]
#print(words)

material = ' '.join(words)
print(material)


font = r'C:\Windows\Fonts\STXINGKA.TTF'

pic = wordcloud.WordCloud(font_path=font,width=800,height=800,background_color='black').generate(material)

pic.to_file('wc.png')
