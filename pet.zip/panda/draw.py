import matplotlib.pyplot as plt
import pandas as pd



src1 = './data2/books.xlsx'
def booksPic():
    df = pd.read_excel(src1,sheet_name='Sheet2')


    print(df)

    x = df['年份']
    y1 = df['京东']
    y2 = df['天猫']
    y3 = df['自营']

    
    pass

src2 = './data2/mrbook.xlsx'


def codebook():

    df = pd.read_excel(src2)
    print(df.head())
    x = df['销量']
    y = df['图书名称']

    for a,b in zip(x,y):
        plt.text(a,b,a,fontdict='left')
    plt.barh(y,x,color = 'green')
    plt.show()
    
    pass

codebook()