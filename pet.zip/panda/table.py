from os import remove
import pandas as pd
import csv


url = 'http://data.sports.sohu.com/nba/nba_players_rank.php?order_by=points'
src = './'


df1=pd.read_html(url)

#print(df1[0])
file = open('nba.csv','w',encoding='utf-8')
data = df1[0].to_string()
#print(data)
d1 = data.split(' ',-1)
print(d1)
while '' in d1:
    d1.remove('')
data = ','.join(d1)
print(data)
#df1[0].to_csv(src+'nba2.csv','w',encoding='gbk')
file.write(data)
file.close()