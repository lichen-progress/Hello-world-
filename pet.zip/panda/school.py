
import requests
from bs4 import BeautifulSoup
import time


#此程序用于爬取学校新闻网站，默认之爬取第一页，其他请自行修改
#使用时要在此文件的目录下新建一个名为“shoolnewstext”的文件夹，爬取下来的新闻会以txt格式存储其中
#不新建应该也可以。。。吧？
#如果使用vscode运行请在vscode中打开原文件夹，以免vscode的内容管理拒绝操作

url = 'https://www.jhun.edu.cn/jdyw/list.htm'
listurl = []


r1 = requests.get(url)
print(r1.status_code)
r1.encoding = 'utf-8'
bs1 = BeautifulSoup(r1.text,'lxml')

#bs1.encode('utf-8')
#print(bs1)


#通过属性来查找元素
# select('查找标签 .class #id > 子标签 ')
a_all = bs1.select('span.Article_Title > a')
#print(a_all)
for i in a_all :
    listurl.append("https://www.jhun.edu.cn"+i.get('href'))

print(listurl)

# f =open('./schoolNews.txt','w')

# f.write('\n'.join(listurl))
# f.close()



def getEssay(url):
    #间隔3s爬取一次
    time.sleep(3)
    #开始爬取新闻内容
    r = requests.get(url)
    print(r.status_code)
    r.encoding = 'utf-8'
    bs = BeautifulSoup(r.text,'lxml')
    #print(bs)
    essay = bs.select('div.info_main > div.article')
    title = essay[0].select('h1.arti-title')
    print(title)
    title = title[0].text
    #print(essay[0])
    title = title.strip('\r\n ')
    print(title)
    f = open('./shoolnewstext/'+f"{title}.txt",'w',encoding='utf-8')

    f.write(essay[0].text)
    f.close

for url in listurl:
    getEssay(url)



