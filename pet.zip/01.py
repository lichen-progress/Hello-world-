#lxml etree 用法基础练习
from lxml import etree
html_str='''<div class="level_one">
<ul>
<li><a href="/index/index/view/id/1.html" title="什么是Java" class="on">什么是Java</a> 
    <a title='java'>JAVA</a> </li>
<li>
    <a href="javascript:" onclick="login(0)" title="Java的版本">
        <a>JAVA版本</a>
     </a>
</li>
<li> <a href='www.java.com' title="Java API文档">Java API文档</a> </li>
</ul>div test1
</div>
<div id='div2' class="level_two" title='div_test_2'>div test2</div>
<div di='div3' class="level_two" title='div_test_3'>div test3</div>'''

#print(html_str)

html=etree.HTML(html_str)
#print(html)
node_all=html.xpath("//li")
print([i.tag == 'li' for i in node_all])

#[i for i in range(1,11)]
li_01_text=etree.tostring(node_all[0],encoding='utf-8')
print(li_01_text.decode('utf-8'))

li_text=[etree.tostring(node_all[i],encoding='utf-8').decode('utf-8') for i in  range(len(node_all))]
print(li_text)