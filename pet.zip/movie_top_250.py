from lxml import etree
import requests
import time
#本程序用于爬取豆瓣影评



#影评网址 = 0代表第一的电影
movielisturl = "https://movie.douban.com/top250?start=0&filter="

moviename = []

moviedirector = []



def crawler(url,code):
    header = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36 Edg/93.0.961.47" }
    r1 = requests.get(url,headers=header)
    print(r1.status_code)
    r1.encoding = 'utf-8'
    #etree对象
    html = etree.HTML(r1.text)
    #获得电影名
    moviename = html.xpath("//div[@class='item']/div/div[@class='hd']/a/span[1]/text()")
    #获得制作者
    moviemaker = html.xpath("//div[@class='item']/div/div[@class='bd']/p[1]/text()")
    moviemaker = ''.join(moviemaker[0])
    print(moviename)
    print(moviemaker)


    

    pass

crawler(movielisturl,0)
